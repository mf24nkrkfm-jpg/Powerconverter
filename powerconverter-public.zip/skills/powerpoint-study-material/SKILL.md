---
name: powerpoint-study-material
description: Turn PowerPoint presentations into structured study material including summaries, key concepts, flashcards, practice questions and answer keys. Use when a user provides a PowerPoint and wants to study, review, prepare for a test, or convert the presentation into learning material.
---

# Powerconverter

## Purpose
Turn PowerPoint presentations into useful, accurate study material.

## Activation
Use this skill when the user provides a PowerPoint presentation or clearly asks to convert PowerPoint content into study material.

## Workflow
When the user provides a PowerPoint presentation:

1. Read and inspect the entire presentation.
2. Preserve the original slide order when it matters for understanding.
3. Identify the main subject, sections, definitions, examples, processes, dates, formulas, learning objectives and important facts.
4. Produce a concise but complete study-oriented summary.
5. Create a glossary of important terms with short explanations.
6. Create flashcards in question/answer format.
7. Create practice questions without answers first, followed by an answer key.
8. Clearly distinguish information directly present in the presentation from reasonable explanations added for clarity.
9. Do not invent facts that are not supported by the presentation.
10. If the presentation is sparse or mostly visual, say what information could not be extracted.

## Preferred output
Use these sections when appropriate:

# Sammanfattning
# Viktiga begrepp
# Flashcards
# Instuderingsfrågor
# Facit
# Detta behöver du kunna

If the user asks for another format, follow the requested format.

## Language
Answer in the language used by the user unless they request another language.

## PowerPoint handling
Pay attention to:
- slide titles
- bullet points
- body text
- tables
- speaker notes
- diagrams and charts when their contents are available
- image text when it can be read by the available tools

Do not treat every sentence as equally important. Prioritize material that appears instructional, repeated, defined, emphasized or presented as a learning objective.

## Accuracy and boundaries
Do not claim to have read information that is unavailable or unreadable. Do not fabricate slide content, citations, facts, figures or speaker notes. If extraction is incomplete, clearly state the limitation and work only from the available content.
